package Modules;

/**
 * Created by abhijeet on 17/3/18.
 */

public class DisplayRoute {

    public String duration;
    public String distance;
    public String instruction;
    public String bus_number;
    public String arrival_time;
    public String no_of_stops;


}
